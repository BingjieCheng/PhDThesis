﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CognitiveAssessmentsC
{
    class eegOLEmarkers
    {
        //TODO get path2file from GUI
        //private String path = @"C:\Users\bcheng\Documents\eegTesting";
        private String path = @"C:\Users\cave-admin\Documents\tryGetEEG_Data_ALX";
        private String pathMarkers;
        private String pathLogFile;
        
        // object for controlling Recorder remotely
        private volatile dynamic m_RecorderApp = null;

        // interfacing with Microsoft component object modules technology
        Type m_ComObjectType;

        // string for holding error messages
        String m_sLastError;

        static private eegOLEmarkers instance = null;

        static public eegOLEmarkers getInstance()
        {
            if (instance == null)
            {
                instance = new eegOLEmarkers();
            }
            return instance;
        }

        private eegOLEmarkers()
        {
            //TODO check path2file exists
            pathMarkers = System.IO.Path.Combine(path, "OLE_test");//include filename but no extention
            pathLogFile = System.IO.Path.Combine(path, "csLogAlx"+DateTime.Now.ToString("YYYYMMdd_HHmmss")+".txt");

            //then log C# to the same place

            logToFile(">>eegOLEmarkers initialising...");

            // get the Recorder COM type
            m_ComObjectType = Type.GetTypeFromProgID("VisionRecorder.Application"); //UNITY 2018 says this is not supported

            // connect with OLE to already RUNNING Recorder instance (seems it starts it here? we should connect to a running instance!)
            m_RecorderApp = Activator.CreateInstance(m_ComObjectType, false);
            //manually connect to eeg etc

            // very important!!! this property must be set to allow two way communication with Recorder
            m_RecorderApp.DisableThreadBlockingMode = 1;

            logToFile("eegOLEmarkers initialised OK!");
        }

        public void setPath(String path)
        {//allow changing path??
            //TODO check path2file exists
            //then log C# to the same place
           // path2file = path;
           // pathLogFile = System.IO.Path.Combine(path2file, "cSharpLog.txt");
        }

        public void startEEGrec()
        {//should I ask for path here??
            logToFile(">>EEG Recording starting...");
            m_RecorderApp.Acquisition.StartRecording(pathMarkers); //ALX: filename , without extention? yes no extention
            logToFile("EEG Recording started");
            ReportStates();
        }

        public void markerStart(String markerName)
        {//tested ok
            setEEGmarker(markerName, MarkerTypes.start);
        }
        public void markerEnd(String markerName)
        {//need to check if this works!
            setEEGmarker(markerName, MarkerTypes.end);
        }

        private void setEEGmarker(String markerName, String sMarkerType)
        {
            try
            {
                m_RecorderApp.Acquisition.SetMarker(markerName, sMarkerType);
                logToFile("EEG set Marker: " + markerName);
                ReportStates();
            }
            catch(Exception error)
            {
                logToFile("-- ERROR: EEG set Marker: " + error.ToString());
                ReportStates();
            }
        }

        public void stopEEGrec()
        {
            // stop the recording
            logToFile(">>EEG Recording stopping...");
            m_RecorderApp.Acquisition.StopRecording();
            //m_RecorderApp.Quit();
            logToFile("EEG Recording stopped");
            ReportStates();
        }

        // utility function for handling errors and warnings from Recorder
        // for now only for debugging
        private void ReportStates()
        {
            if (m_RecorderApp == null) { return; }

            int nState;
            int nAcquisitionState;
            nState = m_RecorderApp.State;
            nAcquisitionState = m_RecorderApp.Acquisition.GetAcquisitionState; // get acquisition state

            logToFile("   __ EEG >>> Current State: " + eegStates.getStateString(nState), false);
            logToFile("   __ EEG >>> Current Acquisition State: " + eegAcquisitionStates.getAcquisitionStatesString(nAcquisitionState), false);
        }

        private void logToFile(String logText, bool addTimeStamp = true)
        {
            String outText;
            if (addTimeStamp == true)
            {
                outText = DateTime.Now.ToString("yyyyMMddhhmmssffffff") + " , " + logText + Environment.NewLine;
            }
            else
            {
                outText = logText + Environment.NewLine;
            }
            System.IO.File.AppendAllText(pathLogFile, outText);
        }

        private struct MarkerTypes
        {
            public const String start = "S";
            public const String end = "E"; //check if this works!
        }

        public class eegStates
        {
            public static int Off = 0;
            public static int Monitoring = 1;
            public static int Calibration = 2;
            public static int ImpedanceCheck = 3;
            public static int Saving = 4;
            public static int SavingCalibration = 5;
            public static int Pause = 6;
            public static int PauseCalibration = 7;
            public static int PauseImpedanceCheck = 8;

            public static String getStateString(int state)
            {
                switch (state)
                {
                    case 0:
                        return "Off";
                    case 1:
                        return "Monitoring";
                    case 2:
                        return "Calibration";
                    case 3:
                        return "ImpedanceCheck";
                    case 4:
                        return "Saving";
                    case 5:
                        return "SavingCalibration";
                    case 6:
                        return "Pause";
                    case 7:
                        return "PauseCalibration";
                    case 8:
                        return "PauseImpedanceCheck";
                    default:
                        return "Unknown State: " + state.ToString();
                }
            }
        }

        public class eegAcquisitionStates
        {
            public static int STOPPED = 0;
            public static int RUNNING = 1;
            public static int WARNING = 2;
            public static int ERROR = 3;

            public static String getAcquisitionStatesString(int state)
            {
                switch (state)
                {
                    case 0:
                        return "STOPPED";
                    case 1:
                        return "RUNNING";
                    case 2:
                        return "WARNING";
                    case 3:
                        return "ERROR";
                    default:
                        return "Unknown State: " + state.ToString();
                }
            }
        }
    }
}

