﻿namespace CognitiveAssessmentsC
{
    partial class frmSpeed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl0 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.btnA = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnD = new System.Windows.Forms.Button();
            this.formTimer = new System.Windows.Forms.Timer(this.components);
            this.clickTimer = new System.Windows.Forms.Timer(this.components);
            this.lblBtnA = new System.Windows.Forms.Label();
            this.lblBtnB = new System.Windows.Forms.Label();
            this.lblBtnC = new System.Windows.Forms.Label();
            this.lblBtnD = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl0
            // 
            this.lbl0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl0.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl0.ForeColor = System.Drawing.Color.White;
            this.lbl0.Location = new System.Drawing.Point(29, 25);
            this.lbl0.Name = "lbl0";
            this.lbl0.Size = new System.Drawing.Size(188, 47);
            this.lbl0.TabIndex = 0;
            this.lbl0.Text = "3372 - ᴎᴒᴨᴥ";
            this.lbl0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl1
            // 
            this.lbl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.ForeColor = System.Drawing.Color.White;
            this.lbl1.Location = new System.Drawing.Point(214, 25);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(188, 47);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "9172 - Ψξᴥᴎ";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl2
            // 
            this.lbl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.ForeColor = System.Drawing.Color.White;
            this.lbl2.Location = new System.Drawing.Point(398, 25);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(188, 47);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "5591 - ξΦᴎΨ";
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl3
            // 
            this.lbl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.ForeColor = System.Drawing.Color.White;
            this.lbl3.Location = new System.Drawing.Point(581, 25);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(188, 47);
            this.lbl3.TabIndex = 3;
            this.lbl3.Text = "8237 - ξᴒᴒᴒ";
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl4
            // 
            this.lbl4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.ForeColor = System.Drawing.Color.White;
            this.lbl4.Location = new System.Drawing.Point(762, 25);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(188, 47);
            this.lbl4.TabIndex = 4;
            this.lbl4.Text = "6612 - ΨΦξξ";
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl9
            // 
            this.lbl9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.ForeColor = System.Drawing.Color.White;
            this.lbl9.Location = new System.Drawing.Point(762, 72);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(188, 47);
            this.lbl9.TabIndex = 9;
            this.lbl9.Text = "9987 - ᴨᴥᴥΦ";
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl8
            // 
            this.lbl8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.ForeColor = System.Drawing.Color.White;
            this.lbl8.Location = new System.Drawing.Point(581, 72);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(188, 47);
            this.lbl8.TabIndex = 8;
            this.lbl8.Text = "9135 - ᴨᴨᴨᴨ";
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl7
            // 
            this.lbl7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.ForeColor = System.Drawing.Color.White;
            this.lbl7.Location = new System.Drawing.Point(398, 72);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(197, 47);
            this.lbl7.TabIndex = 7;
            this.lbl7.Text = "7214 - ΨΨΨΨ";
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl6
            // 
            this.lbl6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.ForeColor = System.Drawing.Color.White;
            this.lbl6.Location = new System.Drawing.Point(214, 72);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(188, 47);
            this.lbl6.TabIndex = 6;
            this.lbl6.Text = "9187 - ηΨξΦ";
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl5
            // 
            this.lbl5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.ForeColor = System.Drawing.Color.White;
            this.lbl5.Location = new System.Drawing.Point(29, 72);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(188, 47);
            this.lbl5.TabIndex = 5;
            this.lbl5.Text = "8992 - ΦΨξη";
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblQuestion
            // 
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.ForeColor = System.Drawing.Color.White;
            this.lblQuestion.Location = new System.Drawing.Point(435, 163);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(130, 43);
            this.lblQuestion.TabIndex = 10;
            this.lblQuestion.Text = "ξΦᴎΨ";
            this.lblQuestion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnA
            // 
            this.btnA.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA.ForeColor = System.Drawing.Color.White;
            this.btnA.Location = new System.Drawing.Point(435, 209);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(130, 48);
            this.btnA.TabIndex = 11;
            this.btnA.Text = "9172";
            this.btnA.UseVisualStyleBackColor = false;
            // 
            // btnB
            // 
            this.btnB.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnB.ForeColor = System.Drawing.Color.White;
            this.btnB.Location = new System.Drawing.Point(435, 263);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(130, 48);
            this.btnB.TabIndex = 12;
            this.btnB.Text = "8237";
            this.btnB.UseVisualStyleBackColor = false;
            // 
            // btnC
            // 
            this.btnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC.ForeColor = System.Drawing.Color.White;
            this.btnC.Location = new System.Drawing.Point(435, 317);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(130, 48);
            this.btnC.TabIndex = 13;
            this.btnC.Text = "5591";
            this.btnC.UseVisualStyleBackColor = false;
            // 
            // btnD
            // 
            this.btnD.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnD.ForeColor = System.Drawing.Color.White;
            this.btnD.Location = new System.Drawing.Point(435, 371);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(130, 48);
            this.btnD.TabIndex = 14;
            this.btnD.Text = "6612";
            this.btnD.UseVisualStyleBackColor = false;
            // 
            // formTimer
            // 
            this.formTimer.Enabled = true;
            this.formTimer.Interval = 30000;
            this.formTimer.Tick += new System.EventHandler(this.formTimer_Tick);
            // 
            // clickTimer
            // 
            this.clickTimer.Interval = 350;
            this.clickTimer.Tick += new System.EventHandler(this.clickTimer_Tick);
            // 
            // lblBtnA
            // 
            this.lblBtnA.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBtnA.ForeColor = System.Drawing.Color.White;
            this.lblBtnA.Location = new System.Drawing.Point(375, 209);
            this.lblBtnA.Name = "lblBtnA";
            this.lblBtnA.Size = new System.Drawing.Size(54, 48);
            this.lblBtnA.TabIndex = 15;
            this.lblBtnA.Text = "(1)";
            this.lblBtnA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBtnB
            // 
            this.lblBtnB.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBtnB.ForeColor = System.Drawing.Color.White;
            this.lblBtnB.Location = new System.Drawing.Point(375, 263);
            this.lblBtnB.Name = "lblBtnB";
            this.lblBtnB.Size = new System.Drawing.Size(54, 48);
            this.lblBtnB.TabIndex = 16;
            this.lblBtnB.Text = "(2)";
            this.lblBtnB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBtnC
            // 
            this.lblBtnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBtnC.ForeColor = System.Drawing.Color.White;
            this.lblBtnC.Location = new System.Drawing.Point(375, 317);
            this.lblBtnC.Name = "lblBtnC";
            this.lblBtnC.Size = new System.Drawing.Size(54, 48);
            this.lblBtnC.TabIndex = 17;
            this.lblBtnC.Text = "(3)";
            this.lblBtnC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBtnD
            // 
            this.lblBtnD.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBtnD.ForeColor = System.Drawing.Color.White;
            this.lblBtnD.Location = new System.Drawing.Point(375, 371);
            this.lblBtnD.Name = "lblBtnD";
            this.lblBtnD.Size = new System.Drawing.Size(54, 48);
            this.lblBtnD.TabIndex = 18;
            this.lblBtnD.Text = "(4)";
            this.lblBtnD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmSpeed
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(982, 490);
            this.ControlBox = false;
            this.Controls.Add(this.lblBtnD);
            this.Controls.Add(this.lblBtnC);
            this.Controls.Add(this.lblBtnB);
            this.Controls.Add(this.lblBtnA);
            this.Controls.Add(this.btnD);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnB);
            this.Controls.Add(this.btnA);
            this.Controls.Add(this.lblQuestion);
            this.Controls.Add(this.lbl9);
            this.Controls.Add(this.lbl8);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.lbl6);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lbl0);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmSpeed";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "Coding Speed Test";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmSpeed_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl0;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Timer formTimer;
        private System.Windows.Forms.Timer clickTimer;
        private System.Windows.Forms.Label lblBtnA;
        private System.Windows.Forms.Label lblBtnB;
        private System.Windows.Forms.Label lblBtnC;
        private System.Windows.Forms.Label lblBtnD;
    }
}