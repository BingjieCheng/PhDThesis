﻿using SantaBarbaraSenseOfDirection_SimpleQuestionnaire.Properties;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SantaBarbaraSenseOfDirection_SimpleQuestionnaire
{
    class Q_Language
    {
        public static readonly string English = "en";
        public static readonly string German = "de"; 
    }

    enum Sex
    {
        Female,
        Male,
        Other,
        None
    }

    public partial class MainWindow : Window
    {
        int partID;
        int partAge;
        Sex partSex;
        int currentQuestionIndex = 0;

        string[] jsonFiles;

        bool dataSaved = false;
        string savepath;

        QuestionnaireJsonDescription questionnaireJson;

        Dictionary<int,QuestionnaireParticipantAnswer> answers;

        public MainWindow()
        {
            InitializeComponent();

            init();
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {//allow only numeric input
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void textBox_PreviewExecuted(object sender, ExecutedRoutedEventArgs e)
        {//don't allow paste or cut 
            if (e.Command == ApplicationCommands.Cut ||
                e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true;
            }
        }

        private void btnEnglish_Click(object sender, RoutedEventArgs e)
        {
            if (checkInitOK())
            {
                startQuestionnaire(Q_Language.English);
            }
        }

        private void btnGerman_Click(object sender, RoutedEventArgs e)
        {
            if (checkInitOK())
            {
                startQuestionnaire(Q_Language.German);
            }
        }

        private bool checkInitOK()
        {
            bool allOK = true;

            //check partID
            if (int.TryParse(txtParticipantID.Text, out partID) == false)
            {
                msgBoxWarn("Please enter numeric only Participant ID!");
                allOK = false;
            }

            //check partAge
            if (int.TryParse(txtParticipantAge.Text, out partAge) == false)
            {
                msgBoxWarn("Please enter numeric only Participant Age!");
                allOK = false;
            }

            //check partSex
            var sex = getAllselRadiobuttons(grpSex);
            if(sex.Count != 1)
            {
                msgBoxWarn("Please select paticipants sex!");
                allOK = false;
            }
            else
            {
                partSex = Sex.None;
                if (sex[0].Name.Equals(rdFemaleSex.Name))
                {
                    partSex = Sex.Female;
                }
                if (sex[0].Name.Equals(rdMaleSex.Name))
                {
                    partSex = Sex.Male;
                }
                if (sex[0].Name.Equals(rdOtherSex.Name))
                {
                    partSex = Sex.Other;
                }

                if (partSex == Sex.None)
                {//do we allow no selection for sex?
                    msgBoxWarn("Please select paticipants sex!");
                    allOK = false;
                }

                //check saveFolder
                if (Directory.Exists(txtPathSave.Text) == false)
                {
                    msgBoxWarn("Please select proper folder to save!");
                    allOK = false;
                }
                else
                {
                    Properties.Settings.Default.saveFolder = txtPathSave.Text;
                    Properties.Settings.Default.Save();
                }

                //check questionnaire folder
                if (Directory.Exists(txtPathQuestions.Text) == true)
                {
                    Properties.Settings.Default.questionsFolder = txtPathQuestions.Text;
                    Properties.Settings.Default.Save();

                    jsonFiles = Directory.GetFiles(txtPathQuestions.Text, "*.json", SearchOption.AllDirectories);
                    if(jsonFiles.Length == 0)
                    {
                        msgBoxWarn("No valid questionnaires fould in " + txtPathQuestions.Text);
                        allOK = false;
                    }
                }
                else
                {
                    msgBoxWarn("Please select proper questionnaire folder!");
                    allOK = false;
                }
            }

            return allOK;
        }

        private void init()
        {
            savepath = "";
            dataSaved = false;

            grdInit.IsEnabled = true;
            grdInit.Visibility = Visibility.Visible;

            grdQuestionnaire.IsEnabled = false;
            grdQuestionnaire.Visibility = Visibility.Collapsed;

            //make sure everything is clear
            txtParticipantAge.Text = "";
            txtParticipantID.Text = "";
            txtPathQuestions.Text = "";
            txtPathSave.Text = "";
            rdFemaleSex.IsChecked = false;
            rdMaleSex.IsChecked = false;

            //load settings
            txtPathQuestions.Text = Properties.Settings.Default.questionsFolder;
            txtPathSave.Text = Properties.Settings.Default.saveFolder;
        }

        private bool loadQuestions(string language, out QuestionnaireJsonDescription questionnaireJson)
        {
            foreach (var file in jsonFiles)
            {
                var fileJson = File.ReadAllText(file);
                var q = new JavaScriptSerializer().Deserialize<QuestionnaireJsonDescription>(fileJson);
                if (q.language.ToLower().Equals(language))
                {
                    questionnaireJson = q;
                    return true;
                }
            }

            questionnaireJson = null;
            return false;
        }

        private void startQuestionnaire(string language)
        {
            btnDone.Visibility = Visibility.Collapsed;

            if (loadQuestions(language, out questionnaireJson) == true)
            {
                grdInit.IsEnabled = false;
                grdInit.Visibility = Visibility.Collapsed;

                grdQuestionnaire.IsEnabled = true;
                grdQuestionnaire.Visibility = Visibility.Visible;

                answers = new Dictionary<int, QuestionnaireParticipantAnswer>();

                currentQuestionIndex = 0;
                lblInstructions.Content = questionnaireJson.instructions;
                lblAgree.Content = questionnaireJson.txtAgree;
                lblDisagree.Content = questionnaireJson.txtDisagree;
                lblAgree.HorizontalContentAlignment = HorizontalAlignment.Right;
                lblDisagree.HorizontalContentAlignment = HorizontalAlignment.Left;

                lblQuestion.HorizontalContentAlignment = HorizontalAlignment.Center;
                lblQuestion.VerticalContentAlignment = VerticalAlignment.Center;

                showCurrentQuestion();
            }
            else
            {
                msgBoxWarn("Questionnaire with language: " + language + " not found in " + txtPathQuestions.Text);
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            currentQuestionIndex--;
            if(currentQuestionIndex < 0)
            {
                currentQuestionIndex = 0;
                msgBoxWarn("You are already at the start of the questionnaire!");
                btnBack.IsEnabled = false;
            }
            if(currentQuestionIndex < questionnaireJson.questions.Count)
            {
                btnNext.IsEnabled = true;
            }
            showCurrentQuestion();
        }

        private void showCurrentQuestion()
        {
            deselectAllRadiobuttons(grpAnswers);
            
            var q = questionnaireJson.questions[currentQuestionIndex];
            lblQuestion.Content = q.content;

            //load answer if it already exists
            if (answers.ContainsKey(q.id)) 
            {
                enableRadiobuttons(grpAnswers, answers[q.id].participantAnswer);
            }
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            //check answer
            var ans = getAllselRadiobuttons(grpAnswers);
            if (ans.Count != 1)
            {//we expect only 1 answer, something went wrong (or user did not answer!)
                msgBoxWarn("Please select 1 answer!");
                return;
            }

            currentQuestionIndex++;
            if (currentQuestionIndex >= questionnaireJson.questions.Count)
            {
                currentQuestionIndex = questionnaireJson.questions.Count - 1;
                msgBoxWarn("The questionnaire is finished!\r\nPress DONE to save data when ready!");
                btnNext.IsEnabled = false;
            }
            if (currentQuestionIndex > 0)
            {
                btnBack.IsEnabled = true;
            }

            if(answers.Count == questionnaireJson.questions.Count)
            {
                btnDone.Visibility = Visibility.Visible;
            }

            showCurrentQuestion();
        }

        private void deselectAllRadiobuttons(DependencyObject dependencyObject)
        {
            foreach (RadioButton radiobutton in FindVisualChildren<RadioButton>(dependencyObject))
            {
                radiobutton.IsChecked = false;
            }
        }

        private void enableRadiobuttons(DependencyObject dependencyObject, string radioName)
        {
            foreach (RadioButton radiobutton in FindVisualChildren<RadioButton>(dependencyObject))
            {
                if (radiobutton.Name.Equals(radioName))
                {
                    radiobutton.IsChecked = true;
                }
            }
        }

        private List<RadioButton> getAllselRadiobuttons(DependencyObject dependencyObject)
        {
            List<RadioButton> radiosSelected = new List<RadioButton>();

            foreach (RadioButton radiobutton in FindVisualChildren<RadioButton>(dependencyObject))
            {
                if(radiobutton.IsChecked == true)
                {
                    radiosSelected.Add(radiobutton);
                }
            }

            return radiosSelected;
        }


        private IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                    if (child != null && child is T)
                    {
                        Debug.WriteLine("FindVisualChildren: " + child.ToString());
                        yield return (T)child;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        Debug.WriteLine("FindVisualChildren childOfChild: " + child.ToString());
                        yield return childOfChild;
                    }
                }
            }
            else
            {
                Debug.WriteLine("FindVisualChildren depObj == null ?? ");
            }
        }

        private void radiogrpAnswers_Click(object sender, RoutedEventArgs e)
        {
            deselectAllRadiobuttons(grpAnswers);
            RadioButton rd = (RadioButton)sender;
            rd.IsChecked = true;

            //save answer
            var q = questionnaireJson.questions[currentQuestionIndex];
            answers[q.id] = new QuestionnaireParticipantAnswer(q.id, q.content, rd.Name);
        }

        private void msgBoxWarn(string warnMsg)
        {
            MessageBox.Show(warnMsg, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void msgBoxHelp(string helpMsg)
        {
            MessageBox.Show(helpMsg, "Instructions", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void btnBrowseQuestionsFolder_Click(object sender, RoutedEventArgs e)
        {
            var saveFolder = selectFolder();
            if (saveFolder.Equals("") == false)
            {
                txtPathQuestions.Text = saveFolder;
            }
        }

        private void btnBrowseSaveFolder_Click(object sender, RoutedEventArgs e)
        {
            var saveFolder = selectFolder();
            if(saveFolder.Equals("") == false)
            {
                txtPathSave.Text = saveFolder;
            }
        }

        private string selectFolder()
        {//in WPF couldn't find openfiledialog that also allows for folder selection
         //so using from windows forms... search better cannot be true! (had to also add reference to  System.Windows.Forms )
            string selectedFolder = "";
            System.Windows.Forms.FolderBrowserDialog selFileOrFolder = new System.Windows.Forms.FolderBrowserDialog();

            System.Windows.Forms.DialogResult result = selFileOrFolder.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                selectedFolder = selFileOrFolder.SelectedPath;
            }

            return selectedFolder;
        }

        private void btnDone_Click(object sender, RoutedEventArgs e)
        {
            saveToFile();
            var ans = MessageBox.Show("Data saved at:\r\n" + savepath +"\r\nRestart?", "Data saved!", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if(ans == MessageBoxResult.Yes)
            {
                init();
            }
            else
            {
                this.Close();
            }
        }

        private void saveToFile()
        {
            var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            var fileName = "pID_" + partID.ToString() + "_" + partSex.ToString() + "_Age_" + partAge.ToString() + "_" + timestamp + ".csv";
            savepath = System.IO.Path.Combine(Properties.Settings.Default.saveFolder, fileName);

            var header = "questionID , questionContent , ParticipantAnswer";
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(savepath, true))
            {
                file.WriteLine(header);
                foreach (var item in answers)
                {
                    var pAns = item.Value.participantAnswer.ToLower().Replace("rd_", ""); //e.g. for radiobutton rd_1 -> 1
                    var line = string.Join(",", item.Value.questionID, item.Value.questionContent, pAns);
                    file.WriteLine(line);
                }
            }
            dataSaved = true;            
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if(dataSaved == false)
            {
                var ans = MessageBox.Show("Data not saved!\r\nQuit Anyway?", "Warning!", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);
                if (ans == MessageBoxResult.No)
                {
                    e.Cancel = true;
                }

            }
        }
    }
}
