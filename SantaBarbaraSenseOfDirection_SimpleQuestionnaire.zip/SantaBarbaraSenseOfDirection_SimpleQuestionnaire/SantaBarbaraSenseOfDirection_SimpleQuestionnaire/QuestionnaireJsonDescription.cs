﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SantaBarbaraSenseOfDirection_SimpleQuestionnaire
{
    class QuestionnaireJsonDescription
    {
        public string language;
        public string instructions;
        public string txtAgree;
        public string txtDisagree;
        public List<Question> questions;
    }

    class Question
    {
        public int id;
        public string content;
    }
}
