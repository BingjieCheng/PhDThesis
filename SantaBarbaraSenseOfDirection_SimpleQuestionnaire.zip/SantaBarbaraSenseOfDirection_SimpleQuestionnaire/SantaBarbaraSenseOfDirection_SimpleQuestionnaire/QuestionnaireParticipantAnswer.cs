﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SantaBarbaraSenseOfDirection_SimpleQuestionnaire
{
    class QuestionnaireParticipantAnswer
    {
        public int questionID { get; private set; }
        public string questionContent { get; private set; }
        public string participantAnswer { get; private set; }

        public QuestionnaireParticipantAnswer(int qID, string qContent, string pAns)
        {
            questionID = qID;
            questionContent = qContent;
            participantAnswer = pAns;
        }
    }
}
